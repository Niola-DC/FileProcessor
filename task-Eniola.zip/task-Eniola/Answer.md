Question 1?
I spent a total of 2hrs on this project.

Question 2?
I defined the contract for processing text in an interface.
I implemented the text processing logic by finding and replacing the most used word.
I made my service class delegate the actual text processing to the TextProcessor implementation, promoting flexibility and testability.
This structure makes it easier to add or switch out different text processing strategies by 
simply creating new implementations of the TextProcessor interface.

Question 3?
Given more time, I would have created a service to download the formatted file rather than just returning it.
I would have integrated a React frontend to consume the API.

Question 4?
I appreciated the task—it was both interesting and well-rounded. It delved into important 
aspects of Java Spring Boot, and showed me my own strengths.
