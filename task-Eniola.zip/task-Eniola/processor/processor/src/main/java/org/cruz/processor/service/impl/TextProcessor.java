package org.cruz.processor.service.impl;

public interface TextProcessor {
    String processText(String content);
}
